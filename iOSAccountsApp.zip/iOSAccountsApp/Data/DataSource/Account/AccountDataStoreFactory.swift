//
//  AccountDataStoreFactory.swift
//  Data
//
//  Created by Malti Maurya on 31/12/21.
//

import Foundation

public class AccountDataStoreFactory {
    
    private let accountAPI: AccountAPI
    
    public init(accountAPI: AccountAPI) {
        self.accountAPI = accountAPI
    }
    
    func createCloudDataStore() -> AccountDataStore{
        return CloudAccountDataStore(accountAPI: accountAPI)
    }
}
