//
//  CloudAccountDataStore.swift
//  Data
//
//  Created by Malti Maurya on 31/12/21.
//

import Combine
import Domain

class CloudAccountDataStore: AccountDataStore {
    
    private let accountAPI: AccountAPI
    
    init(accountAPI: AccountAPI) {
        self.accountAPI = accountAPI
    }
    
    func getBalance() -> AnyPublisher<BalanceEntity, Error> {
        return accountAPI.getBalance()
    }
}
