//
//  AccountDataStore.swift
//  Data
//
//  Created by Malti Maurya on 31/12/21.
//

import Combine
import Domain

protocol AccountDataStore {
    func getBalance() -> AnyPublisher<BalanceEntity, Error>
}
