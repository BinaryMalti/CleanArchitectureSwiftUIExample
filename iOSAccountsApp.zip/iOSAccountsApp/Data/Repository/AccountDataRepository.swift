//
//  AccountDataRepository.swift
//  Data
//
//  Created by Malti Maurya on 31/12/21.
//

import Combine
import Domain

public final class DefaultAccountDataRepository: AccountDataRepository {
    private let accountDataStoreFactory: AccountDataStoreFactory //from API
    public init(accountDataStoreFactory: AccountDataStoreFactory) {
        self.accountDataStoreFactory = accountDataStoreFactory
    }
    
    public func getBalance() -> AnyPublisher<BalanceEntity, Error> {
        let accountDataStore: AccountDataStore = accountDataStoreFactory.createCloudDataStore()
        return accountDataStore.getBalance()
    }
    
}
