//
//  TokenAPI.swift
//  Data
//
//  Created by Malti Maurya on 31/12/21.
//

import Domain
import Combine

public class TokenAPI: NSObject {
    public let endPoint: String
//    public let username: String
//    public let password: String
    
    public init(endpoint: String) {
        self.endPoint = endpoint
//        self.scheduler = ConcurrentDispatchQueueScheduler(qos: DispatchQoS(qosClass: .background, relativePriority: 1))
//        self.username = username
//        self.password = password
    }
    
//    public func getBasicAuthString() -> String {
//        let userPasswordString = "\(self.username):\(self.password)"
//        let userPasswordData = userPasswordString.data(using: .utf8)
//        let base64EncodedCredential = userPasswordData!.base64EncodedString(options: NSData.Base64EncodingOptions(rawValue: 0))
//        let authString = "Basic \(base64EncodedCredential)"
//        return authString
//    }
}
