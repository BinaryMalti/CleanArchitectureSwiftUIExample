//
//  AccountAPI.swift
//  Data
//
//  Created by Malti Maurya on 31/12/21.
//

import Combine
import Domain

public protocol AccountAPI {
    func getBalance() -> AnyPublisher<BalanceEntity, Error>
}

public final class DefaultAccountAPI: TokenAPI, AccountAPI {
    
    public func getBalance() -> AnyPublisher<BalanceEntity, Error> {
        let networker: NetworkerProtocol = Networker()
        let absolutePath = "\(self.endPoint)/api/balance"
        guard let url = URL(string: absolutePath) else {
            print("error")
            return Fail<BalanceEntity, Error>(error: NetworkError.invalidURL).eraseToAnyPublisher()
        }
        let headers: [String:Any] = ["Content-Type": "application/json",
                                     "Authorization" : "8918623815"]
        return networker.get(type: BalanceEntity.self, url: url, headers: headers)
    }
    
    
}
