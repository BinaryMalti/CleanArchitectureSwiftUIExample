//
//  NetworkError.swift
//  Data
//
//  Created by Malti Maurya on 31/12/21.
//

import Foundation

enum NetworkError: Error {
    case invalidURL
}
