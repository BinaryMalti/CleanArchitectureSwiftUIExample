//
//  AccountDataRepository.swift
//  Domain
//
//  Created by Malti Maurya on 31/12/21.
//

import Combine

public protocol AccountDataRepository {
    func getBalance() -> AnyPublisher<BalanceEntity, Error>
}
