//
//  GetBalance.swift
//  Domain
//
//  Created by Malti Maurya on 31/12/21.
//

import Combine

public protocol GetBalanceUseCase: AnyObject {
    func getBalance() -> AnyPublisher<BalanceEntity, Error>
}


public final class DefaultGetBalanceUseCase: GetBalanceUseCase {
    
    private let accountDataRepository: AccountDataRepository
    
    public init(accountDataRepository: AccountDataRepository) {
        self.accountDataRepository = accountDataRepository
    }
    
    public func getBalance() -> AnyPublisher<BalanceEntity, Error> {
        self.accountDataRepository.getBalance()
    }
    
}
