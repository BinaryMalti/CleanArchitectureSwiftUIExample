//
//  BalanceEntity.swift
//  Domain
//
//  Created by Malti Maurya on 31/12/21.
//

import Foundation

public struct BalanceEntity: Codable {
    public let balance: Int?
}


//{
//    "balance": 749586
//}
