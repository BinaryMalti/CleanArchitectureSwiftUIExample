//
//  iOSAccountsAppApp.swift
//  iOSAccountsApp
//
//  Created by Malti Maurya on 30/12/21.
//

import SwiftUI
import Domain

@main
struct iOSAccountsAppApp: App {
    var body: some Scene {
        WindowGroup {
            HomeConfigurator.configureHomeView()
        }
    }
}
