//
//  HomeNavigator.swift
//  iOSAccountsApp
//
//  Created by Malti Maurya on 30/12/21.
//

import SwiftUI

final class UsersRouter {
    
//    public static func destinationForTappedUser() -> some View {
//        return UserDetailConfigurator.configureUserDetailView(with: user)
//    }
}
