//
//  HomeViewModel.swift
//  iOSAccountsApp
//
//  Created by Malti Maurya on 30/12/21.
//

import Combine
import SwiftUI
import Domain
import Data

class HomeViewModel: ObservableObject {
    
    @Published public var balance: String = ""
    
    private var getBalanceUseCase: GetBalanceUseCase
    private var cancellables = Set<AnyCancellable>()
    
    init(balance: String = "",
         getBalanceUseCase: GetBalanceUseCase =
            DefaultGetBalanceUseCase(accountDataRepository: DefaultAccountDataRepository(accountDataStoreFactory: AccountDataStoreFactory(accountAPI: DefaultAccountAPI(endpoint: "http://13.235.89.254:3001"))))) {
        self.balance = balance
        self.getBalanceUseCase = getBalanceUseCase
    }
    
    public func onAppear() {
        self.getBalance()
    }
    
    private func getBalance() {
        getBalanceUseCase.getBalance()
            .receive(on: DispatchQueue.main)
            .sink { completion in
                switch completion {
                case .failure(let error):
                    print(error)
                case .finished: break
                }
            } receiveValue: { [weak self] balanceEntity in
                self?.balance = "INR \(balanceEntity.balance ?? 0)"
            }
            .store(in: &cancellables)
    }
}

