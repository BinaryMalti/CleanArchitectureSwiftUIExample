//
//  HomeView.swift
//  iOSAccountsApp
//
//  Created by Malti Maurya on 30/12/21.
//

import SwiftUI

struct HomeView: View {

    @ObservedObject var viewModel: HomeViewModel
    
    var body: some View {
        NavigationView {
            VStack(alignment: .center, spacing: 8, content: {
                Spacer()
                Text("Transaction List")
                Text(viewModel.balance)
                Spacer()
                List(0..<5) { item in
                    HStack {
                        VStack(alignment: .leading) {
                            Text("Credit").textCase(.uppercase)
                            Text("Descp")
                                .font(.subheadline)
                        }
                        Spacer()
                        Text("INR 00.0")
                    }.padding(0)
                }.padding(0)
            })
            .navigationBarTitle("Binary Accounts", displayMode: .inline)
            .navigationBarItems(trailing:
                                    Button(action: {
                                        print("Edit button pressed...")
                                    }) {
                                        Image("ic_add")
                                            .renderingMode(Image.TemplateRenderingMode?.init(Image.TemplateRenderingMode.original))
                                    }
            )
        }.onAppear(perform: {
            viewModel.onAppear()
        })
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView(viewModel: HomeViewModel())
    }
}
