//
//  HomeConfigurator.swift
//  iOSAccountsApp
//
//  Created by Malti Maurya on 31/12/21.
//

import Foundation

final class HomeConfigurator {
    
    public static func configureHomeView(
        with viewModel: HomeViewModel = HomeViewModel()
    ) -> HomeView{
        
        let homeView = HomeView(viewModel: viewModel)
        return homeView
    }
}
