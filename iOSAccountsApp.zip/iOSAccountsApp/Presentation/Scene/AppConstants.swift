//
//  AppConstants.swift
//  Domain
//
//  Created by Malti Maurya on 31/12/21.
//

import Foundation

public struct AppConstants {
    struct URL {
        static let EndPoint = "http://13.235.89.254:3001"
    }
}
